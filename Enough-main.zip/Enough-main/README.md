# Enough

[![Github Stars](https://img.shields.io/github/stars/tingirifistik/Enough)]()
[![Github Forks](https://img.shields.io/github/forks/tingirifistik/Enough)]()

<img src=https://user-images.githubusercontent.com/51286195/200389355-b3eb9324-f92b-4342-b3a5-b73cbf5e0f6b.PNG width="700" height="350"/>
<img src=https://user-images.githubusercontent.com/51286195/200389361-34e1981f-ed06-4dac-ae58-3386d029c6d6.PNG width="700" height="700"/>

### Kurulum

```console
git clone https://github.com/tingirifistik/Enough
cd Enough
pip3 install -r requirements.txt
python3 enough.py
```

### Telegram Botu Olarak Çalıştırmak İçin

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/tingirifistik/Enough)
